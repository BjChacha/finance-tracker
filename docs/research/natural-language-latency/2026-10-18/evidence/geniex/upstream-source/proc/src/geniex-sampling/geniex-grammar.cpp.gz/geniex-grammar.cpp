// Copyright (c) 2026 Qualcomm Technologies, Inc. and/or its subsidiaries.
// SPDX-License-Identifier: BSD-3-Clause
//
// Adapted from llama.cpp (https://github.com/ggml-org/llama.cpp)
// Original work Copyright (c) 2023-2026 The ggml authors
// Licensed under the MIT License (https://opensource.org/licenses/MIT)

#include "geniex-grammar.h"

#include <algorithm>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <stdexcept>

#include "sampling-vocab.h"

//
// UTF-8 decoding helpers
//

// NOTE: assumes valid utf8 (but checks for overrun)
std::pair<uint32_t, const char *> geniex_decode_utf8(const char *src) {
    static const int lookup[] = {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 2, 3, 4};
    uint8_t first_byte = static_cast<uint8_t>(*src);
    uint8_t highbits = first_byte >> 4;
    int len = lookup[highbits];
    uint8_t mask = (1 << (8 - len)) - 1;
    uint32_t value = first_byte & mask;
    const char *end = src + len;  // may overrun!
    const char *pos = src + 1;
    for (; pos < end && *pos; pos++) {
        value = (value << 6) + (static_cast<uint8_t>(*pos) & 0x3F);
    }
    return std::make_pair(value, pos);
}

std::pair<std::vector<uint32_t>, geniex_partial_utf8> geniex_decode_utf8(const std::string &src,
                                                                     geniex_partial_utf8 partial_start) {
    static const int lookup[] = {1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 2, 2, 3, 4};
    const char *pos = src.c_str();
    std::vector<uint32_t> code_points;

    // common english strings have the same number of codepoints and bytes. `+ 1` for the terminating 0.
    code_points.reserve(src.size() + 1);
    uint32_t value = partial_start.value;
    int n_remain = partial_start.n_remain;

    // continue previous decode, if applicable
    while (*pos != 0 && n_remain > 0) {
        uint8_t next_byte = static_cast<uint8_t>(*pos);
        if ((next_byte >> 6) != 2) {
            // invalid sequence, abort
            code_points.push_back(0);
            return std::make_pair(std::move(code_points), geniex_partial_utf8{0, -1});
        }
        value = (value << 6) + (next_byte & 0x3F);
        ++pos;
        --n_remain;
    }

    if (partial_start.n_remain > 0 && n_remain == 0) {
        code_points.push_back(value);
    }

    // decode any subsequent utf-8 sequences, which may end in an incomplete one
    while (*pos != 0) {
        uint8_t first_byte = static_cast<uint8_t>(*pos);
        uint8_t highbits = first_byte >> 4;
        n_remain = lookup[highbits] - 1;

        if (n_remain < 0) {
            // invalid sequence, abort
            code_points.clear();
            code_points.push_back(0);
            return std::make_pair(std::move(code_points), geniex_partial_utf8{0, n_remain});
        }

        uint8_t mask = (1 << (7 - n_remain)) - 1;
        value = first_byte & mask;

        ++pos;
        while (*pos != 0 && n_remain > 0) {
            value = (value << 6) + (static_cast<uint8_t>(*pos) & 0x3F);
            ++pos;
            --n_remain;
        }
        if (n_remain == 0) {
            code_points.push_back(value);
        }
    }
    code_points.push_back(0);

    return std::make_pair(std::move(code_points), geniex_partial_utf8{value, n_remain});
}

//
// Grammar parsing helpers
//

static bool is_digit_char(char c) { return '0' <= c && c <= '9'; }

static bool is_word_char(char c) {
    return ('a' <= c && c <= 'z') || ('A' <= c && c <= 'Z') || c == '-' || is_digit_char(c);
}

static std::pair<uint32_t, const char *> parse_hex(const char *src, int size) {
    const char *pos = src;
    const char *end = src + size;
    uint32_t value = 0;
    for (; pos < end && *pos; pos++) {
        value <<= 4;
        char c = *pos;
        if ('a' <= c && c <= 'f') {
            value += c - 'a' + 10;
        } else if ('A' <= c && c <= 'F') {
            value += c - 'A' + 10;
        } else if ('0' <= c && c <= '9') {
            value += c - '0';
        } else {
            break;
        }
    }
    if (pos != end) {
        throw std::runtime_error("expecting " + std::to_string(size) + " hex chars at " + src);
    }
    return std::make_pair(value, pos);
}

static const char *parse_space(const char *src, bool newline_ok) {
    const char *pos = src;
    while (*pos == ' ' || *pos == '\t' || *pos == '#' || (newline_ok && (*pos == '\r' || *pos == '\n'))) {
        if (*pos == '#') {
            while (*pos && *pos != '\r' && *pos != '\n') {
                pos++;
            }
        } else {
            pos++;
        }
    }
    return pos;
}

static const char *parse_name(const char *src) {
    const char *pos = src;
    while (is_word_char(*pos)) {
        pos++;
    }
    if (pos == src) {
        throw std::runtime_error(std::string("expecting name at ") + src);
    }
    return pos;
}

static const char *parse_int(const char *src) {
    const char *pos = src;
    while (is_digit_char(*pos)) {
        pos++;
    }
    if (pos == src) {
        throw std::runtime_error(std::string("expecting integer at ") + src);
    }
    return pos;
}

static std::pair<uint32_t, const char *> parse_char(const char *src) {
    if (*src == '\\') {
        switch (src[1]) {
            case 'x':
                return parse_hex(src + 2, 2);
            case 'u':
                return parse_hex(src + 2, 4);
            case 'U':
                return parse_hex(src + 2, 8);
            case 't':
                return std::make_pair('\t', src + 2);
            case 'r':
                return std::make_pair('\r', src + 2);
            case 'n':
                return std::make_pair('\n', src + 2);
            case '\\':
            case '"':
            case '[':
            case ']':
                return std::make_pair(src[1], src + 2);
            default:
                throw std::runtime_error(std::string("unknown escape at ") + src);
        }
    } else if (*src) {
        return geniex_decode_utf8(src);
    }
    throw std::runtime_error("unexpected end of input");
}

static void print_grammar_char(FILE *file, uint32_t c) {
    if (0x20 <= c && c <= 0x7f) {
        fprintf(file, "%c", static_cast<char>(c));
    } else {
        // cop out of encoding UTF-8
        fprintf(file, "<U+%04X>", c);
    }
}

static bool is_char_element(geniex_grammar_element elem) {
    switch (elem.type) {
        case GENIEX_GRETYPE_CHAR:
            return true;
        case GENIEX_GRETYPE_CHAR_NOT:
            return true;
        case GENIEX_GRETYPE_CHAR_ALT:
            return true;
        case GENIEX_GRETYPE_CHAR_RNG_UPPER:
            return true;
        case GENIEX_GRETYPE_CHAR_ANY:
            return true;
        default:
            return false;
    }
}

//
// Grammar parser implementation
//

uint32_t geniex_grammar_parser::get_symbol_id(const char *src, size_t len) {
    uint32_t next_id = static_cast<uint32_t>(symbol_ids.size());
    auto result = symbol_ids.emplace(std::string(src, len), next_id);
    return result.first->second;
}

uint32_t geniex_grammar_parser::generate_symbol_id(const std::string &base_name) {
    uint32_t next_id = static_cast<uint32_t>(symbol_ids.size());
    symbol_ids[base_name + '_' + std::to_string(next_id)] = next_id;
    return next_id;
}

void geniex_grammar_parser::add_rule(uint32_t rule_id, const geniex_grammar_rule &rule) {
    if (rules.size() <= rule_id) {
        rules.resize(rule_id + 1);
    }
    rules[rule_id] = rule;
}

const char *geniex_grammar_parser::parse_alternates(const char *src, const std::string &rule_name, uint32_t rule_id,
                                                  bool is_nested) {
    geniex_grammar_rule rule;
    const char *pos = parse_sequence(src, rule_name, rule, is_nested);
    while (*pos == '|') {
        rule.push_back({GENIEX_GRETYPE_ALT, 0});
        pos = parse_space(pos + 1, true);
        pos = parse_sequence(pos, rule_name, rule, is_nested);
    }
    rule.push_back({GENIEX_GRETYPE_END, 0});
    add_rule(rule_id, rule);
    return pos;
}

const char *geniex_grammar_parser::parse_sequence(const char *src, const std::string &rule_name, geniex_grammar_rule &rule,
                                                bool is_nested) {
    size_t last_sym_start = rule.size();
    const char *pos = src;

    auto handle_repetitions = [&](int min_times, int max_times) {
        if (last_sym_start == rule.size()) {
            throw std::runtime_error(std::string("expecting preceding item to */+/?/{ at ") + pos);
        }

        // apply transformation to previous symbol (last_sym_start to end)
        geniex_grammar_rule prev_rule(rule.begin() + last_sym_start, rule.end());
        if (min_times == 0) {
            rule.resize(last_sym_start);
        } else {
            // Repeat the previous elements (min_times - 1) times
            for (int i = 1; i < min_times; i++) {
                rule.insert(rule.end(), prev_rule.begin(), prev_rule.end());
            }
        }

        uint32_t last_rec_rule_id = 0;
        auto n_opt = max_times < 0 ? 1 : max_times - min_times;

        geniex_grammar_rule rec_rule(prev_rule);
        for (int i = 0; i < n_opt; i++) {
            rec_rule.resize(prev_rule.size());
            uint32_t rec_rule_id = generate_symbol_id(rule_name);
            if (i > 0 || max_times < 0) {
                rec_rule.push_back({GENIEX_GRETYPE_RULE_REF, max_times < 0 ? rec_rule_id : last_rec_rule_id});
            }
            rec_rule.push_back({GENIEX_GRETYPE_ALT, 0});
            rec_rule.push_back({GENIEX_GRETYPE_END, 0});
            add_rule(rec_rule_id, rec_rule);
            last_rec_rule_id = rec_rule_id;
        }
        if (n_opt > 0) {
            rule.push_back({GENIEX_GRETYPE_RULE_REF, last_rec_rule_id});
        }
    };

    while (*pos) {
        if (*pos == '"') {  // literal string
            pos++;
            last_sym_start = rule.size();
            while (*pos != '"') {
                if (!*pos) {
                    throw std::runtime_error("unexpected end of input");
                }
                auto char_pair = parse_char(pos);
                pos = char_pair.second;
                rule.push_back({GENIEX_GRETYPE_CHAR, char_pair.first});
            }
            pos = parse_space(pos + 1, is_nested);
        } else if (*pos == '[') {  // char range(s)
            pos++;
            enum geniex_gretype start_type = GENIEX_GRETYPE_CHAR;
            if (*pos == '^') {
                pos++;
                start_type = GENIEX_GRETYPE_CHAR_NOT;
            }
            last_sym_start = rule.size();
            while (*pos != ']') {
                if (!*pos) {
                    throw std::runtime_error("unexpected end of input");
                }
                auto char_pair = parse_char(pos);
                pos = char_pair.second;
                enum geniex_gretype type = last_sym_start < rule.size() ? GENIEX_GRETYPE_CHAR_ALT : start_type;

                rule.push_back({type, char_pair.first});
                if (pos[0] == '-' && pos[1] != ']') {
                    if (!pos[1]) {
                        throw std::runtime_error("unexpected end of input");
                    }
                    auto endchar_pair = parse_char(pos + 1);
                    pos = endchar_pair.second;
                    rule.push_back({GENIEX_GRETYPE_CHAR_RNG_UPPER, endchar_pair.first});
                }
            }
            pos = parse_space(pos + 1, is_nested);
        } else if (is_word_char(*pos)) {  // rule reference
            const char *name_end = parse_name(pos);
            uint32_t ref_rule_id = get_symbol_id(pos, name_end - pos);
            pos = parse_space(name_end, is_nested);
            last_sym_start = rule.size();
            rule.push_back({GENIEX_GRETYPE_RULE_REF, ref_rule_id});
        } else if (*pos == '(') {  // grouping
            // parse nested alternates into synthesized rule
            pos = parse_space(pos + 1, true);
            uint32_t sub_rule_id = generate_symbol_id(rule_name);
            pos = parse_alternates(pos, rule_name, sub_rule_id, true);
            last_sym_start = rule.size();
            // output reference to synthesized rule
            rule.push_back({GENIEX_GRETYPE_RULE_REF, sub_rule_id});
            if (*pos != ')') {
                throw std::runtime_error(std::string("expecting ')' at ") + pos);
            }
            pos = parse_space(pos + 1, is_nested);
        } else if (*pos == '.') {  // any char
            last_sym_start = rule.size();
            rule.push_back({GENIEX_GRETYPE_CHAR_ANY, 0});
            pos = parse_space(pos + 1, is_nested);
        } else if (*pos == '*') {
            pos = parse_space(pos + 1, is_nested);
            handle_repetitions(0, -1);
        } else if (*pos == '+') {
            pos = parse_space(pos + 1, is_nested);
            handle_repetitions(1, -1);
        } else if (*pos == '?') {
            pos = parse_space(pos + 1, is_nested);
            handle_repetitions(0, 1);
        } else if (*pos == '{') {
            pos = parse_space(pos + 1, is_nested);

            if (!is_digit_char(*pos)) {
                throw std::runtime_error(std::string("expecting an int at ") + pos);
            }
            const char *int_end = parse_int(pos);
            int min_times = std::stoul(std::string(pos, int_end - pos));
            pos = parse_space(int_end, is_nested);

            int max_times = -1;

            if (*pos == '}') {
                max_times = min_times;
                pos = parse_space(pos + 1, is_nested);
            } else if (*pos == ',') {
                pos = parse_space(pos + 1, is_nested);

                if (is_digit_char(*pos)) {
                    const char *int_end = parse_int(pos);
                    max_times = std::stoul(std::string(pos, int_end - pos));
                    pos = parse_space(int_end, is_nested);
                }

                if (*pos != '}') {
                    throw std::runtime_error(std::string("expecting '}' at ") + pos);
                }
                pos = parse_space(pos + 1, is_nested);
            } else {
                throw std::runtime_error(std::string("expecting ',' at ") + pos);
            }
            handle_repetitions(min_times, max_times);
        } else {
            break;
        }
    }
    return pos;
}

const char *geniex_grammar_parser::parse_rule(const char *src) {
    const char *name_end = parse_name(src);
    const char *pos = parse_space(name_end, false);
    size_t name_len = name_end - src;
    uint32_t rule_id = get_symbol_id(src, name_len);
    const std::string name(src, name_len);

    if (!(pos[0] == ':' && pos[1] == ':' && pos[2] == '=')) {
        throw std::runtime_error(std::string("expecting ::= at ") + pos);
    }
    pos = parse_space(pos + 3, true);

    pos = parse_alternates(pos, name, rule_id, false);

    if (*pos == '\r') {
        pos += pos[1] == '\n' ? 2 : 1;
    } else if (*pos == '\n') {
        pos++;
    } else if (*pos) {
        throw std::runtime_error(std::string("expecting newline or end at ") + pos);
    }
    return parse_space(pos, true);
}

bool geniex_grammar_parser::parse(const char *src) {
    try {
        const char *pos = parse_space(src, true);
        while (*pos) {
            pos = parse_rule(pos);
        }
        // Validate the state to ensure that all rules are defined
        for (const auto &rule : rules) {
            if (rule.empty()) {
                throw std::runtime_error("Undefined rule");
            }
            for (const auto &elem : rule) {
                if (elem.type == GENIEX_GRETYPE_RULE_REF) {
                    // Ensure that the rule at that location exists
                    if (elem.value >= rules.size() || rules[elem.value].empty()) {
                        // Get the name of the rule that is missing
                        for (const auto &kv : symbol_ids) {
                            if (kv.second == elem.value) {
                                throw std::runtime_error("Undefined rule identifier '" + kv.first + "'");
                            }
                        }
                    }
                }
            }
        }
    } catch (const std::exception &err) {
        fprintf(stderr, "%s: error parsing grammar: %s\n\n%s\n", __func__, err.what(), src);
        rules.clear();
        return false;
    }

    return true;
}

void geniex_grammar_parser::print(FILE *file) {
    try {
        std::map<uint32_t, std::string> symbol_id_names;
        for (const auto &kv : symbol_ids) {
            symbol_id_names[kv.second] = kv.first;
        }
        for (size_t i = 0, end = rules.size(); i < end; i++) {
            fprintf(file, "%s ::= ", symbol_id_names[i].c_str());
            for (const auto &elem : rules[i]) {
                switch (elem.type) {
                    case GENIEX_GRETYPE_END:
                        fprintf(file, "\n");
                        break;
                    case GENIEX_GRETYPE_ALT:
                        fprintf(file, "| ");
                        break;
                    case GENIEX_GRETYPE_RULE_REF:
                        fprintf(file, "%s ", symbol_id_names[elem.value].c_str());
                        break;
                    case GENIEX_GRETYPE_CHAR:
                        fprintf(file, "[");
                        print_grammar_char(file, elem.value);
                        fprintf(file, "] ");
                        break;
                    case GENIEX_GRETYPE_CHAR_NOT:
                        fprintf(file, "[^");
                        print_grammar_char(file, elem.value);
                        fprintf(file, "] ");
                        break;
                    case GENIEX_GRETYPE_CHAR_RNG_UPPER:
                        fprintf(file, "-");
                        print_grammar_char(file, elem.value);
                        break;
                    case GENIEX_GRETYPE_CHAR_ALT:
                        print_grammar_char(file, elem.value);
                        break;
                    case GENIEX_GRETYPE_CHAR_ANY:
                        fprintf(file, ". ");
                        break;
                }
            }
        }
    } catch (const std::exception &err) {
        fprintf(stderr, "\n%s: error printing grammar: %s\n", __func__, err.what());
    }
}

geniex_grammar_stack geniex_grammar_parser::c_rules() const {
    geniex_grammar_stack ret;
    ret.reserve(rules.size());
    for (const auto &rule : rules) {
        ret.push_back(rule.data());
    }
    return ret;
}

//
// Grammar matching and application
//

// returns true iff pos points to the end of one of the definitions of a rule
static bool geniex_grammar_is_end_of_sequence(const geniex_grammar_element *pos) {
    switch (pos->type) {
        case GENIEX_GRETYPE_END:
            return true;
        case GENIEX_GRETYPE_ALT:
            return true;
        default:
            return false;
    }
}

// returns true iff chr satisfies the char range at pos (regular or inverse range)
// asserts that pos is pointing to a char range element
static std::pair<bool, const geniex_grammar_element *> geniex_grammar_match_char(const geniex_grammar_element *pos,
                                                                             const uint32_t chr) {
    bool found = false;
    bool is_positive_char = pos->type == GENIEX_GRETYPE_CHAR || pos->type == GENIEX_GRETYPE_CHAR_ANY;

    if (!(is_positive_char || pos->type == GENIEX_GRETYPE_CHAR_NOT)) {
        throw std::runtime_error("Expected char range element");
    }

    do {
        if (pos[1].type == GENIEX_GRETYPE_CHAR_RNG_UPPER) {
            // inclusive range, e.g. [a-z]
            found = found || (pos->value <= chr && chr <= pos[1].value);
            pos += 2;
        } else if (pos->type == GENIEX_GRETYPE_CHAR_ANY) {
            // Any character matches "."
            found = true;
            pos += 1;
        } else {
            // exact char match, e.g. [a] or "a"
            found = found || pos->value == chr;
            pos += 1;
        }
    } while (pos->type == GENIEX_GRETYPE_CHAR_ALT);

    return std::make_pair(found == is_positive_char, pos);
}

// returns true iff some continuation of the given partial UTF-8 sequence could satisfy the char
// range at pos (regular or inverse range)
// asserts that pos is pointing to a char range element
static bool geniex_grammar_match_partial_char(const geniex_grammar_element *pos, const geniex_partial_utf8 partial_utf8) {
    bool is_positive_char = pos->type == GENIEX_GRETYPE_CHAR || pos->type == GENIEX_GRETYPE_CHAR_ANY;
    if (!(is_positive_char || pos->type == GENIEX_GRETYPE_CHAR_NOT)) {
        throw std::runtime_error("Expected char range element");
    }

    uint32_t partial_value = partial_utf8.value;
    int n_remain = partial_utf8.n_remain;

    // invalid sequence or 7-bit char split across 2 bytes (overlong)
    if (n_remain < 0 || (n_remain == 1 && partial_value < 2)) {
        return false;
    }

    // range of possible code points this partial UTF-8 sequence could complete to
    uint32_t low = partial_value << (n_remain * 6);
    uint32_t high = low | ((1 << (n_remain * 6)) - 1);

    if (low == 0) {
        if (n_remain == 2) {
            low = 1 << 11;
        } else if (n_remain == 3) {
            low = 1 << 16;
        }
    }

    do {
        if (pos[1].type == GENIEX_GRETYPE_CHAR_RNG_UPPER) {
            // inclusive range, e.g. [a-z]
            if (pos->value <= high && low <= pos[1].value) {
                return is_positive_char;
            }
            pos += 2;
        } else if (pos->type == GENIEX_GRETYPE_CHAR_ANY) {
            // Any character matches "."
            return true;
        } else {
            // exact char match, e.g. [a] or "a"
            if (low <= pos->value && pos->value <= high) {
                return is_positive_char;
            }
            pos += 1;
        }
    } while (pos->type == GENIEX_GRETYPE_CHAR_ALT);

    return !is_positive_char;
}

// transforms a grammar pushdown stack into N possible stacks, all ending
// at a character range (terminal element)
void geniex_grammar_advance_stack(const geniex_grammar_rules &rules, const geniex_grammar_stack &stack,
                                geniex_grammar_stacks &new_stacks) {
    if (stack.empty()) {
        if (std::find(new_stacks.begin(), new_stacks.end(), stack) == new_stacks.end()) {
            new_stacks.emplace_back(stack);
        }
        return;
    }

    const geniex_grammar_element *pos = stack.back();

    switch (pos->type) {
        case GENIEX_GRETYPE_RULE_REF: {
            const size_t rule_id = static_cast<size_t>(pos->value);
            const geniex_grammar_element *subpos = rules[rule_id].data();
            do {
                // init new stack without the top (pos)
                geniex_grammar_stack new_stack(stack.begin(), stack.end() - 1);
                if (!geniex_grammar_is_end_of_sequence(pos + 1)) {
                    // if this rule ref is followed by another element, add that to stack
                    new_stack.push_back(pos + 1);
                }
                if (!geniex_grammar_is_end_of_sequence(subpos)) {
                    // if alternate is nonempty, add to stack
                    new_stack.push_back(subpos);
                }
                geniex_grammar_advance_stack(rules, new_stack, new_stacks);
                while (!geniex_grammar_is_end_of_sequence(subpos)) {
                    // scan to end of alternate def
                    subpos++;
                }
                if (subpos->type == GENIEX_GRETYPE_ALT) {
                    // there's another alternate def of this rule to process
                    subpos++;
                } else {
                    break;
                }
            } while (true);
            break;
        }
        case GENIEX_GRETYPE_CHAR:
        case GENIEX_GRETYPE_CHAR_NOT:
        case GENIEX_GRETYPE_CHAR_ANY:
            if (std::find(new_stacks.begin(), new_stacks.end(), stack) == new_stacks.end()) {
                // only add the stack if it's not a duplicate of one we already have
                new_stacks.emplace_back(stack);
            }
            break;
        default:
            // end of alternate (GENIEX_GRETYPE_END, GENIEX_GRETYPE_ALT) or middle of char range
            // (GENIEX_GRETYPE_CHAR_ALT, GENIEX_GRETYPE_CHAR_RNG_UPPER); stack should never be left on
            // those
            throw std::runtime_error("Invalid grammar stack state");
    }
}

geniex_grammar_candidates geniex_grammar_reject_candidates_for_stack(const geniex_grammar_rules &rules,
                                                                 const geniex_grammar_stack &stack,
                                                                 const geniex_grammar_candidates &candidates) {
    geniex_grammar_candidates rejects;
    rejects.reserve(candidates.size());

    if (stack.empty()) {
        for (const auto &tok : candidates) {
            if (*tok.code_points != 0 || tok.partial_utf8.n_remain != 0) {
                rejects.push_back(tok);
            }
        }
        return rejects;
    }

    const geniex_grammar_element *stack_pos = stack.back();

    geniex_grammar_candidates next_candidates;
    next_candidates.reserve(candidates.size());

    for (const auto &tok : candidates) {
        if (*tok.code_points == 0) {
            // reached end of full codepoints in token, reject iff it ended in a partial sequence
            // that cannot satisfy this position in grammar
            if (tok.partial_utf8.n_remain != 0 && !geniex_grammar_match_partial_char(stack_pos, tok.partial_utf8)) {
                rejects.push_back(tok);
            }
        } else if (geniex_grammar_match_char(stack_pos, *tok.code_points).first) {
            next_candidates.push_back({tok.index, tok.code_points + 1, tok.partial_utf8});
        } else {
            rejects.push_back(tok);
        }
    }

    const auto *stack_pos_after = geniex_grammar_match_char(stack_pos, 0).second;

    // update top of stack to next element, if any
    geniex_grammar_stack stack_after(stack.begin(), stack.end() - 1);
    if (!geniex_grammar_is_end_of_sequence(stack_pos_after)) {
        stack_after.push_back(stack_pos_after);
    }
    geniex_grammar_stacks next_stacks;
    geniex_grammar_advance_stack(rules, stack_after, next_stacks);

    auto next_rejects = geniex_grammar_reject_candidates(rules, next_stacks, next_candidates);
    for (const auto &tok : next_rejects) {
        rejects.push_back({tok.index, tok.code_points - 1, tok.partial_utf8});
    }

    return rejects;
}

std::vector<geniex_grammar_candidate> geniex_grammar_reject_candidates(const geniex_grammar_rules &rules,
                                                                   const geniex_grammar_stacks &stacks,
                                                                   const geniex_grammar_candidates &candidates) {
    if (stacks.empty()) {
        throw std::runtime_error("Empty grammar stacks");
    }

    if (candidates.empty()) {
        return {};
    }

    auto rejects = geniex_grammar_reject_candidates_for_stack(rules, stacks.front(), candidates);

    for (size_t i = 1, size = stacks.size(); i < size; ++i) {
        rejects = geniex_grammar_reject_candidates_for_stack(rules, stacks[i], rejects);
    }

    return rejects;
}

//
// Main grammar API implementation
//

struct geniex_grammar *geniex_grammar_init(geniex_vocab_interface *vocab, const geniex_grammar_element **rules, size_t n_rules,
                                       size_t start_rule_index) {
    if (!vocab || !rules) {
        return nullptr;
    }

    const geniex_grammar_element *pos;

    // copy rule definitions into vectors
    geniex_grammar_rules vec_rules(n_rules);
    for (size_t i = 0; i < n_rules; i++) {
        for (pos = rules[i]; pos->type != GENIEX_GRETYPE_END; pos++) {
            vec_rules[i].push_back(*pos);
        }
        vec_rules[i].push_back({GENIEX_GRETYPE_END, 0});
    }

    // loop over alternates of start rule to build initial stacks
    geniex_grammar_stacks stacks;
    pos = vec_rules[start_rule_index].data();
    do {
        geniex_grammar_stack stack;
        if (!geniex_grammar_is_end_of_sequence(pos)) {
            // if alternate is nonempty, add to stack
            stack.push_back(pos);
        }
        geniex_grammar_advance_stack(vec_rules, stack, stacks);
        while (!geniex_grammar_is_end_of_sequence(pos)) {
            // scan to end of alternate def
            pos++;
        }
        if (pos->type == GENIEX_GRETYPE_ALT) {
            // there's another alternate def of this rule to process
            pos++;
        } else {
            break;
        }
    } while (true);

    return new geniex_grammar{
        vocab,
        std::move(vec_rules),
        std::move(stacks),
        /* .partial_utf8 = */ {},
        /* .lazy =*/false,
        /* .awaiting_trigger = */ false,
        /* .trigger_buffer = */ "",
        /* .trigger_tokens   = */ {},
        /* .trigger_patterns = */ {},
    };
}

struct geniex_grammar *geniex_grammar_init_from_string(geniex_vocab_interface *vocab, const char *grammar_str,
                                                   const char *grammar_root, bool lazy, const char **trigger_patterns,
                                                   size_t num_trigger_patterns, const geniex_token *trigger_tokens,
                                                   size_t num_trigger_tokens) {
    if (!vocab || !grammar_str) {
        return nullptr;
    }

    geniex_grammar_parser parser;

    // if there is a grammar, parse it
    if (!parser.parse(grammar_str) || parser.rules.empty()) {
        fprintf(stderr, "%s: failed to parse grammar\n", __func__);
        return nullptr;
    }

    // Ensure that there is a "root" node.
    if (parser.symbol_ids.find("root") == parser.symbol_ids.end()) {
        fprintf(stderr, "%s: grammar does not contain a 'root' symbol\n", __func__);
        return nullptr;
    }

    std::vector<const geniex_grammar_element *> grammar_rules(parser.c_rules());

    const size_t n_rules = grammar_rules.size();
    const size_t start_rule_index = parser.symbol_ids.at(grammar_root ? grammar_root : "root");

    const geniex_grammar_element *pos;

    // copy rule definitions into vectors
    geniex_grammar_rules vec_rules(n_rules);
    for (size_t i = 0; i < n_rules; i++) {
        for (pos = grammar_rules[i]; pos->type != GENIEX_GRETYPE_END; pos++) {
            vec_rules[i].push_back(*pos);
        }
        vec_rules[i].push_back({GENIEX_GRETYPE_END, 0});
    }

    // loop over alternates of start rule to build initial stacks
    geniex_grammar_stacks stacks;
    pos = vec_rules[start_rule_index].data();
    do {
        geniex_grammar_stack stack;
        if (!geniex_grammar_is_end_of_sequence(pos)) {
            // if alternate is nonempty, add to stack
            stack.push_back(pos);
        }
        geniex_grammar_advance_stack(vec_rules, stack, stacks);
        while (!geniex_grammar_is_end_of_sequence(pos)) {
            // scan to end of alternate def
            pos++;
        }
        if (pos->type == GENIEX_GRETYPE_ALT) {
            // there's another alternate def of this rule to process
            pos++;
        } else {
            break;
        }
    } while (true);

    std::vector<geniex_token> vec_trigger_tokens;
    std::vector<geniex_grammar_trigger_pattern> vec_trigger_patterns;
    for (size_t i = 0; i < num_trigger_tokens; i++) {
        vec_trigger_tokens.push_back(trigger_tokens[i]);
    }
    for (size_t i = 0; i < num_trigger_patterns; i++) {
        auto &trigger = vec_trigger_patterns.emplace_back();
        trigger.pattern = trigger_patterns[i];
        trigger.regex = std::regex(trigger.pattern);
    }

    return new geniex_grammar{
        vocab,
        std::move(vec_rules),
        std::move(stacks),
        /* .partial_utf8 = */ {},
        /* .lazy = */ lazy,
        /* .awaiting_trigger = */ lazy,
        /* .trigger_buffer = */ "",
        std::move(vec_trigger_tokens),
        std::move(vec_trigger_patterns),
    };
}

void geniex_grammar_free(struct geniex_grammar *grammar) {
    if (grammar == nullptr) {
        return;
    }
    delete grammar;
}

struct geniex_grammar *geniex_grammar_clone(const struct geniex_grammar &grammar) {
    auto *result = new geniex_grammar{
        grammar.vocab,          grammar.rules,          grammar.stacks,
        grammar.partial_utf8,   grammar.lazy,           grammar.awaiting_trigger,
        grammar.trigger_buffer, grammar.trigger_tokens, grammar.trigger_patterns,
    };

    // redirect elements in stacks to point to new rules
    for (size_t is = 0; is < result->stacks.size(); is++) {
        for (size_t ie = 0; ie < result->stacks[is].size(); ie++) {
            for (size_t ir0 = 0; ir0 < grammar.rules.size(); ir0++) {
                for (size_t ir1 = 0; ir1 < grammar.rules[ir0].size(); ir1++) {
                    if (grammar.stacks[is][ie] == &grammar.rules[ir0][ir1]) {
                        result->stacks[is][ie] = &result->rules[ir0][ir1];
                    }
                }
            }
        }
    }

    return result;
}

void geniex_grammar_accept_impl(struct geniex_grammar &grammar, uint32_t chr) {
    geniex_grammar_stacks stacks_new;
    stacks_new.reserve(grammar.stacks.size());

    for (const auto &stack : grammar.stacks) {
        if (stack.empty()) {
            continue;
        }

        auto match = geniex_grammar_match_char(stack.back(), chr);
        if (match.first) {
            const geniex_grammar_element *pos = match.second;

            // update top of stack to next element, if any
            geniex_grammar_stack new_stack(stack.begin(), stack.end() - 1);
            if (!geniex_grammar_is_end_of_sequence(pos)) {
                new_stack.push_back(pos);
            }
            geniex_grammar_advance_stack(grammar.rules, new_stack, stacks_new);
        }
    }

    grammar.stacks = std::move(stacks_new);
}

void geniex_grammar_apply(const struct geniex_grammar &grammar, geniex_token_data_array *cur_p) {
    if (!grammar.vocab) {
        return;
    }

    if (grammar.awaiting_trigger) {
        return;
    }

    bool allow_eog = false;
    for (const auto &stack : grammar.stacks) {
        if (stack.empty()) {
            allow_eog = true;
            break;
        }
    }

    std::vector<std::pair<std::vector<uint32_t>, geniex_partial_utf8>> candidates_decoded;
    candidates_decoded.reserve(cur_p->size);

    geniex_grammar_candidates candidates_grammar;
    candidates_grammar.reserve(cur_p->size);

    for (size_t i = 0; i < cur_p->size; ++i) {
        const geniex_token id = cur_p->data[i].id;
        const std::string piece = grammar.vocab->token_to_piece_str(id);

        if (grammar.vocab->is_eog(id)) {
            if (!allow_eog) {
                cur_p->data[i].logit = -INFINITY;
            }
        } else if (piece.empty() || piece[0] == 0) {
            cur_p->data[i].logit = -INFINITY;
        } else {
            candidates_decoded.push_back(geniex_decode_utf8(piece, grammar.partial_utf8));
            candidates_grammar.push_back({i, candidates_decoded.back().first.data(), candidates_decoded.back().second});
        }
    }

    const auto rejects = geniex_grammar_reject_candidates(grammar.rules, grammar.stacks, candidates_grammar);
    for (const auto &reject : rejects) {
        cur_p->data[reject.index].logit = -INFINITY;
    }
}

void geniex_grammar_accept(struct geniex_grammar &grammar, geniex_token token) {
    if (!grammar.vocab) {
        return;
    }

    const auto piece = grammar.vocab->token_to_piece_str(token);

    if (grammar.awaiting_trigger) {
        if (std::find(grammar.trigger_tokens.begin(), grammar.trigger_tokens.end(), token) !=
            grammar.trigger_tokens.end()) {
            grammar.awaiting_trigger = false;
            grammar.trigger_buffer.clear();
            geniex_grammar_accept_str(grammar, piece);
            return;
        } else {
            grammar.trigger_buffer += piece;

            std::smatch match;
            for (const auto &trigger_pattern : grammar.trigger_patterns) {
                if (std::regex_match(grammar.trigger_buffer, match, trigger_pattern.regex)) {
                    grammar.awaiting_trigger = false;
                    // get from the first matched capturing group to the end of the string
                    size_t start = std::string::npos;
                    for (auto i = 1u; i < match.size(); i++) {
                        if (match.length(i) > 0) {
                            start = match.position(i);
                            break;
                        }
                    }
                    if (start == std::string::npos) {
                        start = match.position(0);
                    }
                    auto constrained_str = grammar.trigger_buffer.substr(start);
                    grammar.trigger_buffer.clear();
                    geniex_grammar_accept_str(grammar, constrained_str);
                    return;
                }
            }
            return;
        }
    }

    if (grammar.vocab->is_eog(token)) {
        for (const auto &stack : grammar.stacks) {
            if (stack.empty()) {
                return;
            }
        }
        throw std::runtime_error("Grammar constraint violated: EOG token not allowed");
    }

    geniex_grammar_accept_str(grammar, piece);
}

void geniex_grammar_accept_str(struct geniex_grammar &grammar, const std::string &piece) {
    // Note terminating 0 in decoded string
    const auto decoded = geniex_decode_utf8(piece, grammar.partial_utf8);
    const auto &code_points = decoded.first;

    for (auto it = code_points.begin(), end = code_points.end() - 1; it != end; ++it) {
        geniex_grammar_accept_impl(grammar, *it);
    }

    grammar.partial_utf8 = decoded.second;
    if (grammar.stacks.empty()) {
        throw std::runtime_error("Unexpected empty grammar stack after accepting piece: " + piece);
    }
}